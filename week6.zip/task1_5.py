
from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

(trainX, trainY), _ = mnist.load_data()

trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))

datagen = ImageDataGenerator(rescale=1.0/255.0)

iterator = datagen.flow(trainX, trainY, batch_size=64)

batchX, _ = next(iterator)

print(batchX.min(), batchX.max())