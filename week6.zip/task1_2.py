
from keras.preprocessing.image import load_img, img_to_array, array_to_img

img_path = '/content/drive/MyDrive/ST1_week6/insect1.PNG'

img = load_img(img_path)
print(type(img))

img_array = img_to_array(img)
print(img_array.dtype)
print(img_array.shape)

img_pil = array_to_img(img_array)
print(type(img_pil))