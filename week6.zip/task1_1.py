
from google.colab import drive
drive.mount('/content/drive')

import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img

img_path = img_path = '/content/drive/MyDrive/mydrive/ST1_week6/insect1.PNG'

img = load_img(img_path)

print(type(img))
print(img.format)
print(img.mode)
print(img.size)

plt.imshow(img)
plt.axis('off')
plt.show()