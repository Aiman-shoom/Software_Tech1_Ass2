
from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

(trainX, trainY), _ = mnist.load_data()

trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))

print("Before:", trainX.mean())

datagen = ImageDataGenerator(featurewise_center=True)
datagen.fit(trainX)

iterator = datagen.flow(trainX, trainY, batch_size=64)

batchX, _ = next(iterator)

print("After:", batchX.mean())