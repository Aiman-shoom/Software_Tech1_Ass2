
from google.colab import drive
drive.mount('/content/drive')

import matplotlib.pyplot as plt
import os
from keras.preprocessing.image import load_img, save_img, img_to_array

img_path = '/content/drive/MyDrive/ST1_week6/insect1.PNG'

img = load_img(img_path, color_mode='grayscale')

img_array = img_to_array(img)

save_path = '/content/drive/MyDrive/ST1_week6/insect_gray.PNG'

save_img(save_path, img_array)

img = load_img(save_path)

print(type(img))
print(img.format)
print(img.mode)
print(img.size)

plt.imshow(img, cmap='gray')
plt.axis('off')
plt.show()